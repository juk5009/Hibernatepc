package shop.mtcoding.hiberpc.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

}
